<template>
  <un-flex class="flex-none">
    <slot />
  </un-flex>
</template>

<script setup lang="ts"></script>

<style scoped></style>
