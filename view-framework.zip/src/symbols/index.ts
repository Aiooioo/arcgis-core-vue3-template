export const viewSymbol = Symbol('view')
