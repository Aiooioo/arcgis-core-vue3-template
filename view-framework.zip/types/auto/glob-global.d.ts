/* eslint-disable */
declare global {
  namespace GlobExport {
    type ExportsArcgisHooks0 = typeof import('./../../src/components/arcgis/hooks/useInitView') & typeof import('./../../src/components/arcgis/hooks/useView');
    type ExportsHooks1 = typeof import('./../../globals/hooks/useDragEvent');
  }
}

export {}