/* eslint-disable */
/// <reference path="glob-global.d.ts" />
declare module 'glob:arcgisHooks:./*.ts' {
  export const useInitView: GlobExport.ExportsArcgisHooks0['useInitView']
  export const useView: GlobExport.ExportsArcgisHooks0['useView']
}
declare module 'glob:hooks:./*.ts' {
  export const useDragEvent: GlobExport.ExportsHooks1['useDragEvent']
}
